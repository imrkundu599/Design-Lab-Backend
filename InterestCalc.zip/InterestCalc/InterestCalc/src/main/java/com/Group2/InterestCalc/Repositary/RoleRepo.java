package com.Group2.InterestCalc.Repositary;

import org.springframework.data.jpa.repository.JpaRepository;

import com.Group2.InterestCalc.Resources.Role;

public interface RoleRepo extends JpaRepository<Role, Integer>{

}
