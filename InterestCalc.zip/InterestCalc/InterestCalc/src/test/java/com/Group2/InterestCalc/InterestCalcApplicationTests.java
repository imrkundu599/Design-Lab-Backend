package com.Group2.InterestCalc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InterestCalcApplicationTests {

	@Test
	void contextLoads() {
	}

}
